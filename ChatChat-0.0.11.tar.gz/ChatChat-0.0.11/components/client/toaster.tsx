'use client';

import { Toaster } from 'react-hot-toast';

export const HotToaster = () => {
    return <Toaster />;
};
