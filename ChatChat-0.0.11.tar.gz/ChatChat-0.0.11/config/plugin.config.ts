export const pluginConfig = [
    { name: 'search', description: 'Search in internet.' },
    { name: 'fetch', description: 'Fetch website content.' },
];
