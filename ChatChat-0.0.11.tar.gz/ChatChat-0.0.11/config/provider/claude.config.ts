export const claudeModelConfig = [
    {
        model: 'claude-v1',
    },
    {
        model: 'claude-v1-100k',
    },
    {
        model: 'claude-instant-v1',
    },
    {
        model: 'claude-instant-v1-100k',
    },
];
