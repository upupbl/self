export const cohereModelConfig = [
    {
        model: 'command-nightly',
    },
];
