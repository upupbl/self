type userRole = 'user' | 'manager' | 'admin';
